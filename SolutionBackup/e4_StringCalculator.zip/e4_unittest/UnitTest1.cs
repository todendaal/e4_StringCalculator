﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using e4_StringCalculator;
using e4_StringCalculator.BL;

namespace e4_unittest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_Negatives()
        {
            string teststr = "2,6,-7,9";
            e4_StringCalculator.BL.StringCalc mainCalc = new StringCalc();
            e4_StringCalculator.BL.Results mainResults = mainCalc.CalculateString(teststr);
            Assert.AreEqual(mainResults.FinalResult, 17);
        }

        [TestMethod]
        public void Test_LineBreaks()
        {
            string teststr = "1,2,3" + System.Environment.NewLine + "4" + System.Environment.NewLine + System.Environment.NewLine + "6";
            e4_StringCalculator.BL.StringCalc mainCalc = new StringCalc();
            e4_StringCalculator.BL.Results mainResults = mainCalc.CalculateString(teststr);
            Assert.AreEqual(mainResults.FinalResult, 16);
        }
        [TestMethod]
        public void Test_NewDelimiter()
        {
            string teststr = "//;2;3;4;5,-6";
            e4_StringCalculator.BL.StringCalc mainCalc = new StringCalc();
            e4_StringCalculator.BL.Results mainResults = mainCalc.CalculateString(teststr);
            Assert.AreEqual(mainResults.FinalResult, 9);
        }
        [TestMethod]
        public void Test_NonIntegers()
        {
            string teststr = "//;2;3;4,56;6";
            e4_StringCalculator.BL.StringCalc mainCalc = new StringCalc();
            e4_StringCalculator.BL.Results mainResults = mainCalc.CalculateString(teststr);
            Assert.AreEqual(mainResults.FinalResult, 11);
        }
    }
}
